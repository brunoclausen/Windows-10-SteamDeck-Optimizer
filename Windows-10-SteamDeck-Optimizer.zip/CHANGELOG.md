# Changelog - Windows 10 Steam Deck Optimizer

## 📅 v1.0 - Første version (DD-MM-YYYY)
- Implementeret **Steam Gaming Mode** 🎮
- Tilføjet funktion til at **gendanne originale Windows-indstillinger**
- Automatisk **fejlhåndtering & failsafe** til kritiske tjenester
- **Logføring** af alle ændringer til `SteamDeckOptimizer.log`
- Tilføjet mulighed for **genstart efter optimering**
