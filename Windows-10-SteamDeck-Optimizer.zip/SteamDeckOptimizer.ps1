# Windows 10 Steam Deck Optimizer - PowerShell Script
# Scriptet vil blive erstattet med det fulde PowerShell-script
